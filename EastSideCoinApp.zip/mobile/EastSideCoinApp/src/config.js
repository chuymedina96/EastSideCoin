export const API_URL = "http://192.168.1.125:8000/api"; // Change this manually
export const WS_URL = `ws://192.168.1.125:8000/ws`; // WebSocket base URL

// export const API_URL = "http://172.20.10.2:8000/api"; // Change this manually
// export const WS_URL = `ws://172.20.10.2:8000/ws`; // WebSocket base URL
