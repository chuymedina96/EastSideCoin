import { CommonActions } from "@react-navigation/native";

let navigator;

export function setNavigator(nav) {
  navigator = nav;
}

export function resetNavigation(routeName) {
  if (!navigator) {
    console.warn(`⚠️ Navigation is NOT initialized! Cannot navigate to ${routeName}.`);
    return;
  }

  if (navigator.isReady()) {
    console.log(`🚀 Resetting Navigation to HomeTabs > ${routeName}`);

    navigator.dispatch(
      CommonActions.reset({
        index: 0,
        routes: [{ name: "HomeTabs" }],
      })
    );

    setTimeout(() => {
      navigator.dispatch(
        CommonActions.navigate(routeName) // Navigate *after* reset
      );
    }, 100); // Small delay to avoid race condition
  } else {
    console.warn(`⚠️ Navigation is NOT ready yet! Cannot navigate to ${routeName}.`);
  }
}
